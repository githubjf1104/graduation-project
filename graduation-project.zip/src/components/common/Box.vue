<template>
    <div class="box">提问</div>
</template>
<script>
export default {
  name: 'Box'
}
</script>
<style lang='scss' scoped>
.box{
  height: 20px;
  width: 35px;
  line-height: 20px;
  text-align: center;
  border-radius: 2px;
  border: 1px solid #528aaa;
}
</style>
